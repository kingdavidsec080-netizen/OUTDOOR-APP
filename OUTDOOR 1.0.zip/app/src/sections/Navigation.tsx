import { useState, useEffect } from 'react';
import { X } from 'lucide-react';

const Navigation = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 100);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMenuOpen(false);
    }
  };

  const menuItems = [
    { label: 'Events', id: 'mosaic' },
    { label: 'Categories', id: 'categories' },
    { label: 'Trending', id: 'trending' },
    { label: 'Host', id: 'host' },
    { label: 'Contact', id: 'footer' },
  ];

  return (
    <>
      {/* Fixed Navigation */}
      <nav 
        className={`fixed top-0 left-0 right-0 z-50 px-6 py-4 flex justify-between items-center transition-all duration-300 ${
          isScrolled ? 'bg-off-white/90 backdrop-blur-sm' : 'bg-transparent'
        }`}
      >
        <button 
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          className="font-display font-black text-xl tracking-tight text-near-black"
        >
          OUTDOOR
        </button>
        
        <button 
          onClick={() => setIsMenuOpen(true)}
          className="font-accent font-semibold text-sm uppercase tracking-wide flex items-center gap-2 text-near-black hover:opacity-70 transition-opacity"
        >
          Menu
        </button>
      </nav>

      {/* Full-screen Menu Overlay */}
      <div 
        className={`fixed inset-0 z-[100] bg-near-black transition-transform duration-500 ${
          isMenuOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <div className="h-full flex flex-col px-6 py-4">
          {/* Menu Header */}
          <div className="flex justify-between items-center mb-12">
            <span className="font-display font-black text-xl tracking-tight text-off-white">
              OUTDOOR
            </span>
            <button 
              onClick={() => setIsMenuOpen(false)}
              className="text-off-white hover:opacity-70 transition-opacity"
            >
              <X size={28} />
            </button>
          </div>

          {/* Menu Items */}
          <div className="flex-1 flex flex-col justify-center">
            {menuItems.map((item, index) => (
              <button
                key={item.id}
                onClick={() => scrollToSection(item.id)}
                className="font-display font-black text-4xl md:text-6xl text-off-white uppercase tracking-tight py-4 text-left hover:text-lime transition-colors"
                style={{ animationDelay: `${index * 50}ms` }}
              >
                {item.label}
              </button>
            ))}
          </div>

          {/* Menu CTA */}
          <div className="pb-8">
            <button 
              onClick={() => {
                scrollToSection('featured');
                setIsMenuOpen(false);
              }}
              className="btn-lime w-full text-center"
            >
              Get Tickets
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

export default Navigation;
