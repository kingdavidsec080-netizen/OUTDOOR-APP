import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Check, MessageCircle } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const HostSection = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const headingRef = useRef<HTMLHeadingElement>(null);
  const bodyRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const stickerRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      // Flowing section - elements animate as they enter viewport
      gsap.fromTo(headingRef.current, 
        { x: '-20vw', opacity: 0 }, 
        { 
          x: 0, 
          opacity: 1, 
          scrollTrigger: {
            trigger: headingRef.current,
            start: 'top 80%',
            end: 'top 50%',
            scrub: 0.4,
          }
        }
      );

      gsap.fromTo(bodyRef.current, 
        { y: 24, opacity: 0 }, 
        { 
          y: 0, 
          opacity: 1, 
          scrollTrigger: {
            trigger: bodyRef.current,
            start: 'top 85%',
            end: 'top 60%',
            scrub: 0.4,
          }
        }
      );

      gsap.fromTo(imageRef.current, 
        { x: '50vw', opacity: 0 }, 
        { 
          x: 0, 
          opacity: 1, 
          scrollTrigger: {
            trigger: imageRef.current,
            start: 'top 80%',
            end: 'top 50%',
            scrub: 0.4,
          }
        }
      );

      gsap.fromTo(stickerRef.current, 
        { scale: 0, rotation: 10 }, 
        { 
          scale: 1, 
          rotation: 0, 
          ease: 'back.out(1.6)',
          scrollTrigger: {
            trigger: stickerRef.current,
            start: 'top 85%',
            end: 'top 65%',
            scrub: 0.4,
          }
        }
      );

    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section 
      ref={sectionRef} 
      id="host"
      className="section-flowing bg-off-white z-[90] py-24 min-h-screen"
    >
      <div className="relative px-[6vw]">
        {/* Left Text Block */}
        <div className="max-w-[44vw] pt-[12vh]">
          <h2 
            ref={headingRef}
            className="font-display font-black text-4xl md:text-6xl lg:text-7xl text-near-black mb-8"
          >
            Host with us
          </h2>
          
          <div ref={bodyRef}>
            <p className="font-body text-lg text-near-black mb-8 max-w-[90%]">
              Sell tickets, reach new crowds, and keep control of your guestlist. From house parties to headline shows.
            </p>
            
            <div className="flex flex-col gap-3 mb-10">
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 rounded-full bg-lime flex items-center justify-center">
                  <Check size={14} className="text-near-black" />
                </div>
                <span className="font-body text-near-black">Free to list</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 rounded-full bg-lime flex items-center justify-center">
                  <Check size={14} className="text-near-black" />
                </div>
                <span className="font-body text-near-black">Payouts in 48hrs</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 rounded-full bg-lime flex items-center justify-center">
                  <Check size={14} className="text-near-black" />
                </div>
                <span className="font-body text-near-black">Real-time insights</span>
              </div>
            </div>

            <div className="flex gap-4">
              <button className="btn-lime">
                List an event
              </button>
              <button className="btn-outline bg-off-white flex items-center gap-2">
                <MessageCircle size={16} />
                Talk to us
              </button>
            </div>
          </div>
        </div>

        {/* Right Image */}
        <div 
          ref={imageRef}
          className="absolute image-frame"
          style={{ 
            right: '6vw', 
            top: '16vh', 
            width: '42vw', 
            height: '56vh' 
          }}
        >
          <img 
            src="/host_image.jpg" 
            alt="Event organizer" 
            className="w-full h-full object-cover"
          />
        </div>

        {/* Sticker - HOST */}
        <div 
          ref={stickerRef}
          className="absolute sticker z-30"
          style={{ 
            left: '46vw', 
            top: '54vh', 
            width: '14vw', 
            height: '14vw',
            maxWidth: '160px',
            maxHeight: '160px'
          }}
        >
          <span className="font-display font-black text-lg md:text-xl text-near-black">
            HOST
          </span>
        </div>
      </div>
    </section>
  );
};

export default HostSection;
