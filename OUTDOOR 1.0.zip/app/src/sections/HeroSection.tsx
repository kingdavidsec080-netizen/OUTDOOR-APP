import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const HeroSection = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const photoARef = useRef<HTMLDivElement>(null);
  const photoBRef = useRef<HTMLDivElement>(null);
  const sticker1Ref = useRef<HTMLDivElement>(null);
  const sticker2Ref = useRef<HTMLDivElement>(null);
  const sticker3Ref = useRef<HTMLDivElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      // Load animation (auto-play on mount)
      const loadTl = gsap.timeline();
      
      loadTl
        .fromTo(photoARef.current, 
          { x: '-60vw', opacity: 0 }, 
          { x: 0, opacity: 1, duration: 0.9, ease: 'power3.out' }
        )
        .fromTo(photoBRef.current, 
          { x: '60vw', opacity: 0 }, 
          { x: 0, opacity: 1, duration: 0.9, ease: 'power3.out' }, 
          0.08
        )
        .fromTo(sticker1Ref.current, 
          { scale: 0, rotation: -25 }, 
          { scale: 1, rotation: 0, duration: 0.7, ease: 'back.out(1.6)' }, 
          0.1
        )
        .fromTo(sticker2Ref.current, 
          { scale: 0, rotation: 20 }, 
          { scale: 1, rotation: 0, duration: 0.7, ease: 'back.out(1.6)' }, 
          0.18
        )
        .fromTo(sticker3Ref.current, 
          { scale: 0, rotation: -10 }, 
          { scale: 1, rotation: 0, duration: 0.6, ease: 'back.out(1.6)' }, 
          0.28
        )
        .fromTo(ctaRef.current, 
          { y: 24, opacity: 0 }, 
          { y: 0, opacity: 1, duration: 0.5 }, 
          0.45
        );

      // Scroll-driven exit animation
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
          onLeaveBack: () => {
            // Reset all elements when scrolling back to top
            gsap.set([photoARef.current, photoBRef.current, sticker1Ref.current, sticker2Ref.current, sticker3Ref.current, ctaRef.current], {
              opacity: 1, x: 0, y: 0, scale: 1, rotation: 0
            });
          }
        }
      });

      // ENTRANCE (0-30%): Hold - elements already visible from load animation
      // SETTLE (30-70%): Static
      // EXIT (70-100%): Elements exit
      scrollTl
        .fromTo(photoARef.current, 
          { x: 0, opacity: 1 }, 
          { x: '-55vw', opacity: 0, ease: 'power2.in' }, 
          0.7
        )
        .fromTo(photoBRef.current, 
          { x: 0, opacity: 1 }, 
          { x: '55vw', opacity: 0, ease: 'power2.in' }, 
          0.7
        )
        .fromTo(sticker1Ref.current, 
          { y: 0, rotation: 0, scale: 1, opacity: 1 }, 
          { y: '-40vh', rotation: -18, scale: 0.85, opacity: 0, ease: 'power2.in' }, 
          0.7
        )
        .fromTo(sticker2Ref.current, 
          { y: 0, rotation: 0, scale: 1, opacity: 1 }, 
          { y: '35vh', rotation: 14, scale: 0.85, opacity: 0, ease: 'power2.in' }, 
          0.7
        )
        .fromTo(sticker3Ref.current, 
          { scale: 1, opacity: 1 }, 
          { scale: 0.6, opacity: 0, ease: 'power2.in' }, 
          0.75
        )
        .fromTo(ctaRef.current, 
          { y: 0, opacity: 1 }, 
          { y: 20, opacity: 0, ease: 'power2.in' }, 
          0.8
        );

    }, section);

    return () => ctx.revert();
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section 
      ref={sectionRef} 
      className="section-pinned bg-off-white z-10"
    >
      {/* Photo A - Hero Portrait DJ */}
      <div 
        ref={photoARef}
        className="absolute image-frame"
        style={{ 
          left: '6vw', 
          top: '14vh', 
          width: '34vw', 
          height: '72vh' 
        }}
      >
        <img 
          src="/hero_portrait_dj.jpg" 
          alt="DJ performing" 
          className="w-full h-full object-cover"
        />
      </div>

      {/* Photo B - Crowd */}
      <div 
        ref={photoBRef}
        className="absolute image-frame"
        style={{ 
          right: '6vw', 
          top: '18vh', 
          width: '42vw', 
          height: '40vh' 
        }}
      >
        <img 
          src="/hero_crowd_hands.jpg" 
          alt="Crowd at concert" 
          className="w-full h-full object-cover"
        />
      </div>

      {/* Sticker 1 - OUTDOOR */}
      <div 
        ref={sticker1Ref}
        className="absolute sticker"
        style={{ 
          left: '30vw', 
          top: '10vh', 
          width: '18vw', 
          height: '18vw',
          maxWidth: '200px',
          maxHeight: '200px'
        }}
      >
        <span className="font-display font-black text-lg md:text-2xl text-near-black text-center">
          OUTDOOR
        </span>
      </div>

      {/* Sticker 2 - Find your scene */}
      <div 
        ref={sticker2Ref}
        className="absolute sticker"
        style={{ 
          right: '10vw', 
          top: '62vh', 
          width: '16vw', 
          height: '16vw',
          maxWidth: '180px',
          maxHeight: '180px'
        }}
      >
        <span className="font-display font-bold text-sm md:text-lg text-near-black text-center leading-tight px-2">
          Find your scene.
        </span>
      </div>

      {/* Sticker 3 - Starburst */}
      <div 
        ref={sticker3Ref}
        className="absolute sticker"
        style={{ 
          left: '42vw', 
          top: '58vh', 
          width: '10vw', 
          height: '10vw',
          maxWidth: '120px',
          maxHeight: '120px'
        }}
      >
        <span className="font-accent font-semibold text-[8px] md:text-xs text-near-black text-center leading-tight px-2">
          TICKETS • EVENTS • COMMUNITY
        </span>
      </div>

      {/* CTA Row */}
      <div 
        ref={ctaRef}
        className="absolute flex gap-4"
        style={{ 
          left: '6vw', 
          bottom: '6vh' 
        }}
      >
        <button 
          onClick={() => scrollToSection('mosaic')}
          className="btn-lime"
        >
          Browse events
        </button>
        <button 
          onClick={() => scrollToSection('host')}
          className="btn-outline bg-off-white"
        >
          Host with us
        </button>
      </div>
    </section>
  );
};

export default HeroSection;
