import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const mosaicTiles = [
  { id: 1, img: '/mosaic_tile_01.jpg', style: { left: '6vw', top: '10vh', width: '26vw', height: '34vh' } },
  { id: 2, img: '/mosaic_tile_02.jpg', style: { left: '34vw', top: '10vh', width: '26vw', height: '34vh' } },
  { id: 3, img: '/mosaic_tile_03.jpg', style: { left: '62vw', top: '10vh', width: '32vw', height: '34vh' } },
  { id: 4, img: '/mosaic_tile_04.jpg', style: { left: '6vw', top: '48vh', width: '34vw', height: '40vh' } },
  { id: 5, img: '/mosaic_tile_05.jpg', style: { left: '42vw', top: '48vh', width: '26vw', height: '40vh' } },
  { id: 6, img: '/mosaic_tile_06.jpg', style: { left: '70vw', top: '48vh', width: '24vw', height: '40vh' } },
];

const MosaicSection = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const tilesRef = useRef<(HTMLDivElement | null)[]>([]);
  const stickerRef = useRef<HTMLDivElement>(null);
  const ctaRef = useRef<HTMLButtonElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        }
      });

      // ENTRANCE (0-30%): Tiles fly in from different directions
      tilesRef.current.forEach((tile, i) => {
        if (!tile) return;
        const directions = [
          { x: '-60vw', y: '-40vh' },
          { x: '0', y: '-60vh' },
          { x: '60vw', y: '-40vh' },
          { x: '-60vw', y: '40vh' },
          { x: '0', y: '60vh' },
          { x: '60vw', y: '40vh' },
        ];
        const dir = directions[i];
        
        scrollTl.fromTo(tile, 
          { x: dir.x, y: dir.y, opacity: 0 }, 
          { x: 0, y: 0, opacity: 1, ease: 'none' }, 
          i * 0.02
        );
      });

      // Sticker pops in
      scrollTl.fromTo(stickerRef.current, 
        { scale: 0, rotation: -20 }, 
        { scale: 1, rotation: 0, ease: 'back.out(1.5)' }, 
        0.12
      );

      // CTA fades in
      scrollTl.fromTo(ctaRef.current, 
        { y: 30, opacity: 0 }, 
        { y: 0, opacity: 1, ease: 'none' }, 
        0.18
      );

      // EXIT (70-100%): Elements exit
      tilesRef.current.forEach((tile, i) => {
        if (!tile) return;
        const directions = [
          { x: '-40vw', y: '-30vh' },
          { x: '0', y: '-40vh' },
          { x: '40vw', y: '-30vh' },
          { x: '-40vw', y: '30vh' },
          { x: '0', y: '40vh' },
          { x: '40vw', y: '30vh' },
        ];
        const dir = directions[i];
        
        scrollTl.fromTo(tile, 
          { x: 0, y: 0, opacity: 1 }, 
          { x: dir.x, y: dir.y, opacity: 0, ease: 'power2.in' }, 
          0.7 + i * 0.01
        );
      });

      scrollTl.fromTo(stickerRef.current, 
        { scale: 1, opacity: 1 }, 
        { scale: 0.7, opacity: 0, ease: 'power2.in' }, 
        0.75
      );

      scrollTl.fromTo(ctaRef.current, 
        { opacity: 1 }, 
        { opacity: 0, ease: 'power2.in' }, 
        0.8
      );

    }, section);

    return () => ctx.revert();
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section 
      ref={sectionRef} 
      id="mosaic"
      className="section-pinned bg-off-white z-20"
    >
      {/* Mosaic Tiles */}
      {mosaicTiles.map((tile, index) => (
        <div
          key={tile.id}
          ref={el => { tilesRef.current[index] = el; }}
          className="absolute image-frame border-4"
          style={tile.style}
        >
          <img 
            src={tile.img} 
            alt={`Event ${tile.id}`} 
            className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
          />
        </div>
      ))}

      {/* Sticker - OUTDOOR EVENTS */}
      <div 
        ref={stickerRef}
        className="absolute sticker z-30"
        style={{ 
          left: '44vw', 
          top: '38vh', 
          width: '18vw', 
          height: '18vw',
          maxWidth: '200px',
          maxHeight: '200px'
        }}
      >
        <span className="font-display font-black text-sm md:text-xl text-near-black text-center leading-tight px-2">
          OUTDOOR<br/>EVENTS
        </span>
      </div>

      {/* CTA */}
      <button 
        ref={ctaRef}
        onClick={() => scrollToSection('weekend')}
        className="absolute btn-lime"
        style={{ 
          left: '6vw', 
          bottom: '6vh' 
        }}
      >
        Explore the calendar
      </button>
    </section>
  );
};

export default MosaicSection;
