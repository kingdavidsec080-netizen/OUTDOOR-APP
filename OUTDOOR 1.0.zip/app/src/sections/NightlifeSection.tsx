import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const NightlifeSection = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const leftImageRef = useRef<HTMLDivElement>(null);
  const rightTopRef = useRef<HTMLDivElement>(null);
  const rightBottomRef = useRef<HTMLDivElement>(null);
  const stickerRef = useRef<HTMLDivElement>(null);
  const ctaRef = useRef<HTMLButtonElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        }
      });

      // ENTRANCE (0-30%)
      scrollTl.fromTo(leftImageRef.current, 
        { x: '-70vw', opacity: 0 }, 
        { x: 0, opacity: 1, ease: 'none' }, 
        0
      );

      scrollTl.fromTo(rightTopRef.current, 
        { x: '70vw', y: '-20vh', opacity: 0 }, 
        { x: 0, y: 0, opacity: 1, ease: 'none' }, 
        0.08
      );

      scrollTl.fromTo(rightBottomRef.current, 
        { x: '70vw', y: '20vh', opacity: 0 }, 
        { x: 0, y: 0, opacity: 1, ease: 'none' }, 
        0.12
      );

      scrollTl.fromTo(stickerRef.current, 
        { scale: 0, rotation: 14 }, 
        { scale: 1, rotation: 0, ease: 'back.out(1.6)' }, 
        0.16
      );

      scrollTl.fromTo(ctaRef.current, 
        { y: 20, opacity: 0 }, 
        { y: 0, opacity: 1, ease: 'none' }, 
        0.18
      );

      // EXIT (70-100%)
      scrollTl.fromTo(leftImageRef.current, 
        { opacity: 1 }, 
        { opacity: 0, ease: 'power2.in' }, 
        0.7
      );

      scrollTl.fromTo(rightTopRef.current, 
        { opacity: 1 }, 
        { opacity: 0, ease: 'power2.in' }, 
        0.72
      );

      scrollTl.fromTo(rightBottomRef.current, 
        { opacity: 1 }, 
        { opacity: 0, ease: 'power2.in' }, 
        0.74
      );

      scrollTl.fromTo(stickerRef.current, 
        { scale: 1, opacity: 1 }, 
        { scale: 0.7, opacity: 0, ease: 'power2.in' }, 
        0.75
      );

      scrollTl.fromTo(ctaRef.current, 
        { opacity: 1 }, 
        { opacity: 0, ease: 'power2.in' }, 
        0.8
      );

    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section 
      ref={sectionRef} 
      className="section-pinned bg-near-black z-[70]"
    >
      {/* Left Portrait Image */}
      <div 
        ref={leftImageRef}
        className="absolute image-frame-light"
        style={{ 
          left: '6vw', 
          top: '14vh', 
          width: '40vw', 
          height: '72vh' 
        }}
      >
        <img 
          src="/nightlife_left_portrait.jpg" 
          alt="Nightlife portrait" 
          className="w-full h-full object-cover"
        />
      </div>

      {/* Right Top Image */}
      <div 
        ref={rightTopRef}
        className="absolute image-frame-light"
        style={{ 
          left: '50vw', 
          top: '14vh', 
          width: '44vw', 
          height: '34vh' 
        }}
      >
        <img 
          src="/nightlife_right_top_bar.jpg" 
          alt="Bar interior" 
          className="w-full h-full object-cover"
        />
      </div>

      {/* Right Bottom Image */}
      <div 
        ref={rightBottomRef}
        className="absolute image-frame-light"
        style={{ 
          left: '50vw', 
          top: '52vh', 
          width: '44vw', 
          height: '34vh' 
        }}
      >
        <img 
          src="/nightlife_right_bottom_dance.jpg" 
          alt="Dancefloor" 
          className="w-full h-full object-cover"
        />
      </div>

      {/* Sticker - NIGHTLIFE */}
      <div 
        ref={stickerRef}
        className="absolute sticker z-30"
        style={{ 
          left: '42vw', 
          top: '42vh', 
          width: '18vw', 
          height: '18vw',
          maxWidth: '200px',
          maxHeight: '200px'
        }}
      >
        <span className="font-display font-black text-lg md:text-2xl text-near-black text-center">
          NIGHTLIFE
        </span>
      </div>

      {/* CTA */}
      <button 
        ref={ctaRef}
        className="absolute btn-lime"
        style={{ left: '6vw', bottom: '6vh' }}
      >
        Explore nightlife
      </button>
    </section>
  );
};

export default NightlifeSection;
