import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const FeaturedSection = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const stickerRef = useRef<HTMLDivElement>(null);
  const ctaRef = useRef<HTMLButtonElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        }
      });

      // ENTRANCE (0-30%)
      scrollTl.fromTo(imageRef.current, 
        { x: '-70vw', opacity: 0 }, 
        { x: 0, opacity: 1, ease: 'none' }, 
        0
      );

      scrollTl.fromTo(panelRef.current, 
        { x: '40vw', opacity: 0 }, 
        { x: 0, opacity: 1, ease: 'none' }, 
        0.1
      );

      scrollTl.fromTo(stickerRef.current, 
        { scale: 0, rotation: -18 }, 
        { scale: 1, rotation: 0, ease: 'back.out(1.6)' }, 
        0.14
      );

      scrollTl.fromTo(ctaRef.current, 
        { y: 20, opacity: 0 }, 
        { y: 0, opacity: 1, ease: 'none' }, 
        0.18
      );

      // EXIT (70-100%)
      scrollTl.fromTo(imageRef.current, 
        { y: 0, opacity: 1 }, 
        { y: '-30vh', opacity: 0, ease: 'power2.in' }, 
        0.7
      );

      scrollTl.fromTo(panelRef.current, 
        { x: 0, opacity: 1 }, 
        { x: '30vw', opacity: 0, ease: 'power2.in' }, 
        0.7
      );

      scrollTl.fromTo(stickerRef.current, 
        { scale: 1, opacity: 1 }, 
        { scale: 0.7, opacity: 0, ease: 'power2.in' }, 
        0.75
      );

      scrollTl.fromTo(ctaRef.current, 
        { opacity: 1 }, 
        { opacity: 0, ease: 'power2.in' }, 
        0.8
      );

    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section 
      ref={sectionRef} 
      id="featured"
      className="section-pinned bg-off-white z-40"
    >
      {/* Large Feature Image */}
      <div 
        ref={imageRef}
        className="absolute image-frame"
        style={{ 
          left: '6vw', 
          top: '14vh', 
          width: '56vw', 
          height: '72vh' 
        }}
      >
        <img 
          src="/featured_block_party.jpg" 
          alt="Sunset Block Party" 
          className="w-full h-full object-cover"
        />
      </div>

      {/* Right Info Panel */}
      <div 
        ref={panelRef}
        className="absolute bg-off-white flex flex-col justify-center"
        style={{ 
          left: '64vw', 
          top: '14vh', 
          width: '30vw', 
          height: '72vh',
          padding: '2rem'
        }}
      >
        <span className="font-accent font-semibold text-sm uppercase tracking-wider text-text-secondary mb-4">
          Featured Drop
        </span>
        <h3 className="font-display font-black text-3xl md:text-4xl lg:text-5xl text-near-black mb-4">
          Sunset Block Party
        </h3>
        <p className="font-body text-base text-text-secondary mb-6">
          Sat, Aug 23 • Rooftop • 18+
        </p>
        <p className="font-body text-base text-near-black mb-8 max-w-[90%]">
          DJs, street food, and open-air dancing until midnight.
        </p>
        <button 
          ref={ctaRef}
          className="btn-lime self-start"
        >
          Get tickets
        </button>
      </div>

      {/* Sticker - FEATURED */}
      <div 
        ref={stickerRef}
        className="absolute sticker z-30"
        style={{ 
          left: '48vw', 
          top: '10vh', 
          width: '16vw', 
          height: '16vw',
          maxWidth: '180px',
          maxHeight: '180px'
        }}
      >
        <span className="font-display font-black text-sm md:text-lg text-near-black text-center">
          FEATURED
        </span>
      </div>
    </section>
  );
};

export default FeaturedSection;
