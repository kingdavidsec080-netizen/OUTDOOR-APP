import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Bell } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const trendingCards = [
  { id: 1, img: '/trending_01.jpg', title: 'Electric Nights' },
  { id: 2, img: '/trending_02.jpg', title: 'Golden Hour' },
  { id: 3, img: '/trending_03.jpg', title: 'Neon Dreams' },
];

const TrendingSection = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const headingRef = useRef<HTMLHeadingElement>(null);
  const cardsRef = useRef<(HTMLDivElement | null)[]>([]);
  const stickerRef = useRef<HTMLDivElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      // Flowing section - elements animate as they enter viewport
      gsap.fromTo(headingRef.current, 
        { x: '-20vw', opacity: 0 }, 
        { 
          x: 0, 
          opacity: 1, 
          scrollTrigger: {
            trigger: headingRef.current,
            start: 'top 80%',
            end: 'top 50%',
            scrub: 0.4,
          }
        }
      );

      cardsRef.current.forEach((card) => {
        if (!card) return;
        gsap.fromTo(card, 
          { y: '40vh', rotation: 3, opacity: 0 }, 
          { 
            y: 0, 
            rotation: 0, 
            opacity: 1, 
            scrollTrigger: {
              trigger: card,
              start: 'top 85%',
              end: 'top 55%',
              scrub: 0.4,
            }
          }
        );
      });

      gsap.fromTo(stickerRef.current, 
        { scale: 0, rotation: 12 }, 
        { 
          scale: 1, 
          rotation: 0, 
          ease: 'back.out(1.6)',
          scrollTrigger: {
            trigger: stickerRef.current,
            start: 'top 80%',
            end: 'top 60%',
            scrub: 0.4,
          }
        }
      );

      gsap.fromTo(ctaRef.current, 
        { y: 20, opacity: 0 }, 
        { 
          y: 0, 
          opacity: 1, 
          scrollTrigger: {
            trigger: ctaRef.current,
            start: 'top 90%',
            end: 'top 70%',
            scrub: 0.4,
          }
        }
      );

    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section 
      ref={sectionRef} 
      id="trending"
      className="section-flowing bg-off-white z-50 py-24"
    >
      {/* Heading */}
      <h2 
        ref={headingRef}
        className="font-display font-black text-4xl md:text-6xl text-near-black mb-12 px-[6vw]"
      >
        TRENDING NOW
      </h2>

      {/* Horizontal Strip */}
      <div className="flex gap-6 px-[6vw] mb-12 overflow-x-auto pb-4">
        {trendingCards.map((card, index) => (
          <div
            key={card.id}
            ref={el => { cardsRef.current[index] = el; }}
            className="image-frame border-4 flex-shrink-0 relative group cursor-pointer"
            style={{ width: '28vw', minWidth: '300px', height: '34vh' }}
          >
            <img 
              src={card.img} 
              alt={card.title} 
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            />
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-near-black/80 to-transparent p-4">
              <span className="font-accent font-semibold text-off-white text-lg">{card.title}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Sticker - HOT */}
      <div 
        ref={stickerRef}
        className="absolute sticker z-30"
        style={{ 
          left: '62vw', 
          top: '18vh', 
          width: '10vw', 
          height: '10vw',
          maxWidth: '120px',
          maxHeight: '120px'
        }}
      >
        <span className="font-display font-black text-lg md:text-xl text-near-black">
          HOT
        </span>
      </div>

      {/* CTA Row */}
      <div 
        ref={ctaRef}
        className="flex gap-4 px-[6vw]"
      >
        <button className="btn-outline bg-off-white">
          View all trending
        </button>
        <button className="btn-lime flex items-center gap-2">
          <Bell size={16} />
          Set a reminder
        </button>
      </div>
    </section>
  );
};

export default TrendingSection;
