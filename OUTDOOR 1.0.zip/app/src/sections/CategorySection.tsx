import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const categoryTiles = [
  { id: 1, img: '/category_tile_01.jpg', style: { left: '6vw', top: '30vh', width: '30vw', height: '56vh' } },
  { id: 2, img: '/category_tile_02.jpg', style: { left: '38vw', top: '18vh', width: '24vw', height: '30vh' } },
  { id: 3, img: '/category_tile_03.jpg', style: { left: '64vw', top: '18vh', width: '30vw', height: '30vh' } },
  { id: 4, img: '/category_tile_04.jpg', style: { left: '38vw', top: '52vh', width: '24vw', height: '34vh' } },
  { id: 5, img: '/category_tile_05.jpg', style: { left: '64vw', top: '52vh', width: '30vw', height: '34vh' } },
];

const CategorySection = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const headingRef = useRef<HTMLHeadingElement>(null);
  const tilesRef = useRef<(HTMLDivElement | null)[]>([]);
  const stickerRef = useRef<HTMLDivElement>(null);
  const ctaRef = useRef<HTMLButtonElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        }
      });

      // ENTRANCE (0-30%)
      scrollTl.fromTo(headingRef.current, 
        { x: '-30vw', opacity: 0 }, 
        { x: 0, opacity: 1, ease: 'none' }, 
        0
      );

      // Tiles enter from different directions
      const tileDirections = [
        { x: '-60vw', y: '30vh' },
        { x: '0', y: '-60vh' },
        { x: '60vw', y: '0' },
        { x: '0', y: '60vh' },
        { x: '60vw', y: '30vh' },
      ];

      tilesRef.current.forEach((tile, i) => {
        if (!tile) return;
        const dir = tileDirections[i];
        scrollTl.fromTo(tile, 
          { x: dir.x, y: dir.y, opacity: 0 }, 
          { x: 0, y: 0, opacity: 1, ease: 'none' }, 
          0.06 + i * 0.02
        );
      });

      scrollTl.fromTo(stickerRef.current, 
        { scale: 0, rotation: -12 }, 
        { scale: 1, rotation: 0, ease: 'back.out(1.6)' }, 
        0.16
      );

      scrollTl.fromTo(ctaRef.current, 
        { y: 20, opacity: 0 }, 
        { y: 0, opacity: 1, ease: 'none' }, 
        0.18
      );

      // EXIT (70-100%)
      scrollTl.fromTo(headingRef.current, 
        { opacity: 1 }, 
        { opacity: 0, ease: 'power2.in' }, 
        0.7
      );

      tilesRef.current.forEach((tile, i) => {
        if (!tile) return;
        scrollTl.fromTo(tile, 
          { opacity: 1 }, 
          { opacity: 0, ease: 'power2.in' }, 
          0.7 + i * 0.01
        );
      });

      scrollTl.fromTo(stickerRef.current, 
        { scale: 1, opacity: 1 }, 
        { scale: 0.7, opacity: 0, ease: 'power2.in' }, 
        0.75
      );

      scrollTl.fromTo(ctaRef.current, 
        { opacity: 1 }, 
        { opacity: 0, ease: 'power2.in' }, 
        0.8
      );

    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section 
      ref={sectionRef} 
      id="categories"
      className="section-pinned bg-off-white z-[80]"
    >
      {/* Heading */}
      <h2 
        ref={headingRef}
        className="absolute font-display font-black text-4xl md:text-6xl lg:text-7xl text-near-black max-w-[40vw]"
        style={{ left: '6vw', top: '10vh' }}
      >
        FIND YOUR VIBE
      </h2>

      {/* Category Tiles */}
      {categoryTiles.map((tile, index) => (
        <div
          key={tile.id}
          ref={el => { tilesRef.current[index] = el; }}
          className="absolute image-frame border-4 group cursor-pointer"
          style={tile.style}
        >
          <img 
            src={tile.img} 
            alt={`Category ${tile.id}`} 
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
        </div>
      ))}

      {/* Sticker - MUSIC • ART • FOOD • SPORT */}
      <div 
        ref={stickerRef}
        className="absolute sticker z-30"
        style={{ 
          left: '30vw', 
          top: '20vh', 
          width: '18vw', 
          height: '18vw',
          maxWidth: '200px',
          maxHeight: '200px'
        }}
      >
        <span className="font-accent font-semibold text-[8px] md:text-xs text-near-black text-center leading-tight px-2">
          MUSIC • ART • FOOD • SPORT
        </span>
      </div>

      {/* CTA */}
      <button 
        ref={ctaRef}
        className="absolute btn-lime"
        style={{ left: '6vw', bottom: '6vh' }}
      >
        Browse categories
      </button>
    </section>
  );
};

export default CategorySection;
