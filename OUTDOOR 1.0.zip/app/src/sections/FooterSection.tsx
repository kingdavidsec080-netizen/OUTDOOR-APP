import { useRef, useLayoutEffect, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Instagram, HelpCircle, FileText, Shield } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const FooterSection = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const headingRef = useRef<HTMLDivElement>(null);
  const formRef = useRef<HTMLDivElement>(null);
  const stickerRef = useRef<HTMLDivElement>(null);
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      // Flowing section - elements animate as they enter viewport
      gsap.fromTo(headingRef.current, 
        { y: 24, opacity: 0 }, 
        { 
          y: 0, 
          opacity: 1, 
          scrollTrigger: {
            trigger: headingRef.current,
            start: 'top 85%',
            end: 'top 60%',
            scrub: 0.4,
          }
        }
      );

      gsap.fromTo(formRef.current, 
        { x: '30vw', opacity: 0 }, 
        { 
          x: 0, 
          opacity: 1, 
          scrollTrigger: {
            trigger: formRef.current,
            start: 'top 85%',
            end: 'top 60%',
            scrub: 0.4,
          }
        }
      );

      gsap.fromTo(stickerRef.current, 
        { scale: 0, rotation: -10 }, 
        { 
          scale: 1, 
          rotation: 0, 
          ease: 'back.out(1.6)',
          scrollTrigger: {
            trigger: stickerRef.current,
            start: 'top 90%',
            end: 'top 70%',
            scrub: 0.4,
          }
        }
      );

    }, section);

    return () => ctx.revert();
  }, []);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubscribed(true);
      setEmail('');
    }
  };

  return (
    <section 
      ref={sectionRef} 
      id="footer"
      className="section-flowing bg-near-black z-[100] py-24 min-h-[80vh]"
    >
      <div className="relative px-[6vw]">
        <div className="flex flex-col lg:flex-row justify-between gap-12">
          {/* Left Column - Contact */}
          <div ref={headingRef} className="max-w-[40vw]">
            <h2 className="font-display font-black text-4xl md:text-6xl text-off-white mb-6">
              Ready to go out?
            </h2>
            <p className="font-body text-lg text-off-white/70 mb-8">
              Drop your email for weekly drops and early access.
            </p>

            {/* Links */}
            <div className="flex flex-wrap gap-6 mt-12">
              <a 
                href="#" 
                className="flex items-center gap-2 text-off-white/70 hover:text-lime transition-colors"
              >
                <Instagram size={18} />
                <span className="font-body text-sm">Instagram</span>
              </a>
              <a 
                href="#" 
                className="flex items-center gap-2 text-off-white/70 hover:text-lime transition-colors"
              >
                <HelpCircle size={18} />
                <span className="font-body text-sm">Support</span>
              </a>
              <a 
                href="#" 
                className="flex items-center gap-2 text-off-white/70 hover:text-lime transition-colors"
              >
                <FileText size={18} />
                <span className="font-body text-sm">Terms</span>
              </a>
              <a 
                href="#" 
                className="flex items-center gap-2 text-off-white/70 hover:text-lime transition-colors"
              >
                <Shield size={18} />
                <span className="font-body text-sm">Privacy</span>
              </a>
            </div>
          </div>

          {/* Right Column - Form */}
          <div 
            ref={formRef}
            className="w-full lg:w-[40vw]"
          >
            {subscribed ? (
              <div className="bg-lime/10 border border-lime/30 rounded-lg p-8 text-center">
                <div className="w-16 h-16 rounded-full bg-lime flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">🎉</span>
                </div>
                <h3 className="font-display font-bold text-2xl text-off-white mb-2">
                  You&apos;re in!
                </h3>
                <p className="font-body text-off-white/70">
                  Watch your inbox for weekly event drops.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-4">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email"
                  className="flex-1 px-6 py-4 bg-off-white/10 border border-off-white/20 rounded-none font-body text-off-white placeholder:text-off-white/50 focus:outline-none focus:border-lime transition-colors"
                  required
                />
                <button 
                  type="submit"
                  className="btn-lime whitespace-nowrap"
                >
                  Subscribe
                </button>
              </form>
            )}
          </div>
        </div>

        {/* Sticker - LET'S GO */}
        <div 
          ref={stickerRef}
          className="absolute sticker z-30"
          style={{ 
            left: '44vw', 
            top: '58vh', 
            width: '14vw', 
            height: '14vw',
            maxWidth: '160px',
            maxHeight: '160px'
          }}
        >
          <span className="font-display font-black text-sm md:text-lg text-near-black text-center leading-tight px-2">
            LET&apos;S<br/>GO
          </span>
        </div>

        {/* Bottom Legal Row */}
        <div className="mt-24 pt-8 border-t border-off-white/10 flex flex-col sm:flex-row justify-between items-center gap-4">
          <span className="font-display font-black text-xl text-off-white">
            OUTDOOR
          </span>
          <span className="font-body text-sm text-off-white/50">
            © {new Date().getFullYear()} OUTDOOR. All rights reserved.
          </span>
        </div>
      </div>
    </section>
  );
};

export default FooterSection;
