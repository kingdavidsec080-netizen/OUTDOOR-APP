import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const weekendCards = [
  { id: 1, img: '/weekend_card_01.jpg' },
  { id: 2, img: '/weekend_card_02.jpg' },
  { id: 3, img: '/weekend_card_03.jpg' },
  { id: 4, img: '/weekend_card_04.jpg' },
  { id: 5, img: '/weekend_card_05.jpg' },
  { id: 6, img: '/weekend_card_06.jpg' },
];

const WeekendSection = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const headingRef = useRef<HTMLHeadingElement>(null);
  const subheadRef = useRef<HTMLParagraphElement>(null);
  const cardsRef = useRef<(HTMLDivElement | null)[]>([]);
  const stickerRef = useRef<HTMLDivElement>(null);
  const ctaRef = useRef<HTMLButtonElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        }
      });

      // ENTRANCE (0-30%)
      scrollTl.fromTo(headingRef.current, 
        { x: '-40vw', opacity: 0 }, 
        { x: 0, opacity: 1, ease: 'none' }, 
        0
      );

      scrollTl.fromTo(subheadRef.current, 
        { x: '-30vw', opacity: 0 }, 
        { x: 0, opacity: 1, ease: 'none' }, 
        0.08
      );

      cardsRef.current.forEach((card, i) => {
        if (!card) return;
        scrollTl.fromTo(card, 
          { y: '60vh', rotation: 6, opacity: 0 }, 
          { y: 0, rotation: 0, opacity: 1, ease: 'none' }, 
          0.1 + i * 0.02
        );
      });

      scrollTl.fromTo(stickerRef.current, 
        { scale: 0, rotation: 12 }, 
        { scale: 1, rotation: 0, ease: 'back.out(1.6)' }, 
        0.16
      );

      scrollTl.fromTo(ctaRef.current, 
        { y: 20, opacity: 0 }, 
        { y: 0, opacity: 1, ease: 'none' }, 
        0.18
      );

      // EXIT (70-100%)
      scrollTl.fromTo(headingRef.current, 
        { x: 0, opacity: 1 }, 
        { x: '-20vw', opacity: 0, ease: 'power2.in' }, 
        0.7
      );

      scrollTl.fromTo(subheadRef.current, 
        { x: 0, opacity: 1 }, 
        { x: '-20vw', opacity: 0, ease: 'power2.in' }, 
        0.72
      );

      cardsRef.current.forEach((card, i) => {
        if (!card) return;
        scrollTl.fromTo(card, 
          { x: 0, opacity: 1 }, 
          { x: '30vw', opacity: 0, ease: 'power2.in' }, 
          0.7 + i * 0.01
        );
      });

      scrollTl.fromTo(stickerRef.current, 
        { y: 0, opacity: 1 }, 
        { y: '30vh', opacity: 0, ease: 'power2.in' }, 
        0.75
      );

      scrollTl.fromTo(ctaRef.current, 
        { opacity: 1 }, 
        { opacity: 0, ease: 'power2.in' }, 
        0.8
      );

    }, section);

    return () => ctx.revert();
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section 
      ref={sectionRef} 
      id="weekend"
      className="section-pinned bg-off-white z-30"
    >
      {/* Heading */}
      <h2 
        ref={headingRef}
        className="absolute font-display font-black text-4xl md:text-6xl lg:text-7xl text-near-black"
        style={{ left: '6vw', top: '8vh' }}
      >
        THIS WEEKEND
      </h2>

      {/* Subhead */}
      <p 
        ref={subheadRef}
        className="absolute font-body text-base md:text-lg text-text-secondary max-w-[34vw]"
        style={{ left: '6vw', top: '18vh' }}
      >
        Fresh drops, local gems, last-minute plans.
      </p>

      {/* Grid Container */}
      <div 
        className="absolute grid grid-cols-3 gap-4"
        style={{ 
          left: '44vw', 
          top: '14vh', 
          width: '50vw', 
          height: '72vh' 
        }}
      >
        {weekendCards.map((card, index) => (
          <div
            key={card.id}
            ref={el => { cardsRef.current[index] = el; }}
            className="image-frame border-4 h-full"
          >
            <img 
              src={card.img} 
              alt={`Weekend event ${card.id}`} 
              className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
            />
          </div>
        ))}
      </div>

      {/* Sticker - NEW DROPS */}
      <div 
        ref={stickerRef}
        className="absolute sticker z-30"
        style={{ 
          left: '36vw', 
          top: '56vh', 
          width: '14vw', 
          height: '14vw',
          maxWidth: '160px',
          maxHeight: '160px'
        }}
      >
        <span className="font-display font-black text-sm md:text-lg text-near-black text-center">
          NEW<br/>DROPS
        </span>
      </div>

      {/* CTA */}
      <button 
        ref={ctaRef}
        onClick={() => scrollToSection('featured')}
        className="absolute btn-lime"
        style={{ left: '6vw', top: '30vh' }}
      >
        See what&apos;s on
      </button>
    </section>
  );
};

export default WeekendSection;
