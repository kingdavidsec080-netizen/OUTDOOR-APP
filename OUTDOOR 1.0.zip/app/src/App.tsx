import { useState } from 'react';
import './App.css';

// Import screens
import Discover from './screens/Discover';
import Profile from './screens/Profile';
import CreateEvent from './screens/CreateEvent';
import BottomNav from './components/BottomNav';
import EventDetailModal from './components/EventDetailModal';

export type Tab = 'discover' | 'create' | 'profile';

export interface Event {
  id: string;
  emoji: string;
  title: string;
  host: {
    name: string;
    phone: string;
    avatar?: string;
  };
  location: string;
  date: string;
  time: string;
  category: string;
  description?: string;
  entryFee?: string;
  isGoing?: boolean;
}

// Sample events data
export const sampleEvents: Event[] = [
  {
    id: '1',
    emoji: '🏠',
    title: "Jide's Friday Grill",
    host: { name: 'Jide', phone: '+234 801 234 5678' },
    location: 'No 5 Ogba',
    date: 'Tonight',
    time: '8:00 PM',
    category: 'House Party',
    description: 'Come through for good food, drinks and vibes! BYOB.',
    entryFee: 'Free',
    isGoing: true,
  },
  {
    id: '2',
    emoji: '💍',
    title: 'Owambe Special',
    host: { name: 'Amina Events', phone: '+234 802 345 6789' },
    location: '101 Event Center',
    date: 'Saturday',
    time: '4:00 PM',
    category: 'Wedding',
    description: 'Traditional wedding celebration. Come prepared to dance!',
    entryFee: 'Free',
    isGoing: true,
  },
  {
    id: '3',
    emoji: '🏨',
    title: 'Hotel Pool Party',
    host: { name: 'Radisson Blu', phone: '+234 803 456 7890' },
    location: 'Radisson Blu, VI',
    date: 'Sunday',
    time: '2:00 PM',
    category: 'Party',
    description: 'Day party by the pool. Music, drinks, and fun in the sun.',
    entryFee: '₦5,000',
  },
  {
    id: '4',
    emoji: '🍾',
    title: 'Champagne Fridays',
    host: { name: 'Quilox', phone: '+234 804 567 8901' },
    location: 'Quilox, VI',
    date: 'Friday',
    time: '11:00 PM',
    category: 'Nightlife',
    description: 'The hottest Friday night party in Lagos. VIP sections available.',
    entryFee: '₦10,000',
  },
  {
    id: '5',
    emoji: '🎓',
    title: 'UNILAG Campus Hangout',
    host: { name: 'Campus Vibes', phone: '+234 805 678 9012' },
    location: 'UNILAG Campus',
    date: 'Tomorrow',
    time: '3:00 PM',
    category: 'Campus',
    description: 'Meet and greet for students. Games, food, and networking.',
    entryFee: 'Free',
  },
];

function App() {
  const [activeTab, setActiveTab] = useState<Tab>('discover');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null);

  const handleTabChange = (tab: Tab) => {
    if (tab === 'create') {
      setShowCreateModal(true);
      return;
    }
    setActiveTab(tab);
  };

  const handleEventClick = (event: Event) => {
    setSelectedEvent(event);
  };

  const renderScreen = () => {
    switch (activeTab) {
      case 'discover':
        return <Discover onEventClick={handleEventClick} />;
      case 'profile':
        return <Profile onEventClick={handleEventClick} />;
      default:
        return <Discover onEventClick={handleEventClick} />;
    }
  };

  return (
    <div className="mobile-container">
      {/* Main Content */}
      <div className="pb-24">
        {renderScreen()}
      </div>

      {/* Bottom Navigation */}
      <BottomNav activeTab={activeTab} onTabChange={handleTabChange} />

      {/* Create Event Modal */}
      {showCreateModal && (
        <CreateEvent onClose={() => setShowCreateModal(false)} />
      )}

      {/* Event Detail Modal */}
      {selectedEvent && (
        <EventDetailModal 
          event={selectedEvent} 
          onClose={() => setSelectedEvent(null)} 
        />
      )}
    </div>
  );
}

export default App;
