import { useState } from 'react';
import { X, MapPin, Clock, Calendar } from 'lucide-react';

interface CreateEventProps {
  onClose: () => void;
}

const categories = [
  { emoji: '🏠', label: 'House Party' },
  { emoji: '💍', label: 'Wedding' },
  { emoji: '🏨', label: 'Hotel' },
  { emoji: '🍾', label: 'Nightlife' },
  { emoji: '🎓', label: 'Campus' },
  { emoji: '🍔', label: 'Food' },
  { emoji: '🎵', label: 'Music' },
  { emoji: '🏀', label: 'Sports' },
];

const CreateEvent = ({ onClose }: CreateEventProps) => {
  const [step, setStep] = useState(1);
  const [eventData, setEventData] = useState({
    title: '',
    category: '',
    emoji: '',
    date: '',
    time: '',
    location: '',
    description: '',
    entryFee: '',
    phone: '',
  });

  const handleCategorySelect = (category: string, emoji: string) => {
    setEventData({ ...eventData, category, emoji });
  };

  const handlePost = () => {
    // In real app, this would save to backend
    onClose();
  };

  const isStep1Valid = eventData.title && eventData.category;
  const isStep2Valid = eventData.date && eventData.time && eventData.location;

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-gray-100">
          <button onClick={onClose} className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center">
            <X className="w-5 h-5 text-gray-600" />
          </button>
          <h2 className="text-lg font-bold text-gray-800">Host a Jolly</h2>
          <div className="w-10" />
        </div>

        {/* Progress */}
        <div className="flex gap-2 px-5 pt-4">
          {[1, 2, 3].map((s) => (
            <div
              key={s}
              className={`flex-1 h-2 rounded-full transition-colors ${
                s <= step ? 'bg-purple-600' : 'bg-gray-200'
              }`}
            />
          ))}
        </div>

        {/* Content */}
        <div className="p-5 overflow-y-auto max-h-[60vh]">
          {step === 1 && (
            <div className="space-y-5">
              <p className="text-gray-500 text-center">Put your event on the map instantly.</p>
              
              {/* Title Input */}
              <div>
                <label className="text-sm font-semibold text-gray-700 mb-2 block">Event Title</label>
                <input
                  type="text"
                  placeholder="e.g., Friday Night Vibes"
                  className="input-field"
                  value={eventData.title}
                  onChange={(e) => setEventData({ ...eventData, title: e.target.value })}
                />
              </div>

              {/* Category Selection */}
              <div>
                <label className="text-sm font-semibold text-gray-700 mb-3 block">Select Category</label>
                <div className="grid grid-cols-2 gap-3">
                  {categories.map((cat) => (
                    <button
                      key={cat.label}
                      onClick={() => handleCategorySelect(cat.label, cat.emoji)}
                      className={`flex items-center gap-3 p-4 rounded-2xl transition-all ${
                        eventData.category === cat.label
                          ? 'bg-purple-100 border-2 border-purple-500'
                          : 'bg-gray-50 border-2 border-transparent hover:bg-gray-100'
                      }`}
                    >
                      <span className="text-2xl">{cat.emoji}</span>
                      <span className={`font-semibold ${
                        eventData.category === cat.label ? 'text-purple-700' : 'text-gray-700'
                      }`}>
                        {cat.label}
                      </span>
                      {eventData.category === cat.label && (
                        <span className="ml-auto text-purple-600">✓</span>
                      )}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-5">
              {/* Date */}
              <div>
                <label className="text-sm font-semibold text-gray-700 mb-2 block flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  Date
                </label>
                <input
                  type="date"
                  className="input-field"
                  value={eventData.date}
                  onChange={(e) => setEventData({ ...eventData, date: e.target.value })}
                />
              </div>

              {/* Time */}
              <div>
                <label className="text-sm font-semibold text-gray-700 mb-2 block flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  Time
                </label>
                <input
                  type="time"
                  className="input-field"
                  value={eventData.time}
                  onChange={(e) => setEventData({ ...eventData, time: e.target.value })}
                />
              </div>

              {/* Location */}
              <div>
                <label className="text-sm font-semibold text-gray-700 mb-2 block flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  Location
                </label>
                <input
                  type="text"
                  placeholder="Search location..."
                  className="input-field"
                  value={eventData.location}
                  onChange={(e) => setEventData({ ...eventData, location: e.target.value })}
                />
              </div>

              {/* Map Preview Area */}
              <div className="h-32 rounded-2xl bg-gradient-to-br from-purple-50 to-blue-50 flex items-center justify-center">
                <button className="flex items-center gap-2 px-4 py-2 rounded-full bg-white shadow-sm text-purple-600 font-semibold text-sm">
                  <MapPin className="w-4 h-4" />
                  Pin on map
                </button>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-5">
              {/* Description */}
              <div>
                <label className="text-sm font-semibold text-gray-700 mb-2 block">Description</label>
                <textarea
                  placeholder="What's the vibe? Any entry fee?"
                  rows={4}
                  className="input-field resize-none"
                  value={eventData.description}
                  onChange={(e) => setEventData({ ...eventData, description: e.target.value })}
                />
              </div>

              {/* Entry Fee */}
              <div>
                <label className="text-sm font-semibold text-gray-700 mb-2 block">Entry Fee (optional)</label>
                <input
                  type="text"
                  placeholder="e.g., Free or ₦5,000"
                  className="input-field"
                  value={eventData.entryFee}
                  onChange={(e) => setEventData({ ...eventData, entryFee: e.target.value })}
                />
              </div>

              {/* Phone Number */}
              <div>
                <label className="text-sm font-semibold text-gray-700 mb-2 block">Your Phone Number</label>
                <input
                  type="tel"
                  placeholder="+234 ..."
                  className="input-field"
                  value={eventData.phone}
                  onChange={(e) => setEventData({ ...eventData, phone: e.target.value })}
                />
                <p className="text-xs text-gray-500 mt-1">This will be shared with attendees</p>
              </div>
            </div>
          )}
        </div>

        {/* Footer Buttons */}
        <div className="p-5 border-t border-gray-100">
          {step < 3 ? (
            <button
              onClick={() => setStep(step + 1)}
              disabled={step === 1 ? !isStep1Valid : !isStep2Valid}
              className={`w-full py-4 rounded-full font-bold text-lg transition-all ${
                (step === 1 ? isStep1Valid : isStep2Valid)
                  ? 'btn-primary'
                  : 'bg-gray-200 text-gray-400 cursor-not-allowed'
              }`}
            >
              Continue
            </button>
          ) : (
            <button
              onClick={handlePost}
              className="btn-primary"
            >
              Post Event 🚀
            </button>
          )}
          
          {step > 1 && (
            <button
              onClick={() => setStep(step - 1)}
              className="w-full mt-3 py-3 text-gray-500 font-semibold"
            >
              Back
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default CreateEvent;
