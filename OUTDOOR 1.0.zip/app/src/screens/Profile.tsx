import { useState } from 'react';
import { Settings, MapPin, Calendar } from 'lucide-react';
import { sampleEvents, type Event } from '../App';

interface ProfileProps {
  onEventClick: (event: Event) => void;
}

const Profile = ({ onEventClick }: ProfileProps) => {
  const [activeTab, setActiveTab] = useState<'upcoming' | 'past' | 'hosted'>('upcoming');

  const stats = {
    jollies: 12,
    hosted: 5,
    points: 84,
  };

  const upcomingEvents = sampleEvents.filter(e => e.isGoing);
  const hostedEvents = sampleEvents.slice(0, 2);

  const getEventsForTab = () => {
    switch (activeTab) {
      case 'upcoming':
        return upcomingEvents;
      case 'hosted':
        return hostedEvents;
      default:
        return [];
    }
  };

  return (
    <div className="p-5 pt-14">
      {/* Settings Button */}
      <div className="flex justify-end mb-4">
        <button className="w-10 h-10 rounded-full bg-white flex items-center justify-center shadow-sm">
          <Settings className="w-5 h-5 text-gray-600" />
        </button>
      </div>

      {/* Profile Card */}
      <div className="bg-white rounded-3xl p-6 shadow-sm mb-6">
        {/* Avatar */}
        <div className="flex flex-col items-center">
          <div className="w-24 h-24 rounded-full bg-gradient-to-br from-purple-100 to-blue-100 flex items-center justify-center text-5xl mb-4 border-4 border-white shadow-lg">
            😎
          </div>
          <h2 className="text-2xl font-extrabold text-gray-800">Any</h2>
          <div className="flex items-center gap-1 text-gray-500 mt-1">
            <MapPin className="w-4 h-4" />
            <span className="text-sm">Kano</span>
          </div>
        </div>

        {/* Stats */}
        <div className="flex justify-around mt-6 pt-6 border-t border-gray-100">
          <div className="text-center">
            <span className="text-2xl font-extrabold text-purple-600">{stats.jollies}</span>
            <p className="text-xs text-gray-500 font-semibold uppercase tracking-wide mt-1">Jollies</p>
          </div>
          <div className="text-center">
            <span className="text-2xl font-extrabold text-purple-600">{stats.hosted}</span>
            <p className="text-xs text-gray-500 font-semibold uppercase tracking-wide mt-1">Hosted</p>
          </div>
          <div className="text-center">
            <span className="text-2xl font-extrabold text-purple-600">{stats.points}</span>
            <p className="text-xs text-gray-500 font-semibold uppercase tracking-wide mt-1">Points</p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mb-5">
        {(['upcoming', 'past', 'hosted'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`flex-1 py-3 px-4 rounded-2xl font-semibold text-sm capitalize transition-all ${
              activeTab === tab
                ? 'bg-purple-600 text-white'
                : 'bg-white text-gray-600'
            }`}
          >
            {tab === 'upcoming' ? 'Upcoming Jollies' : tab}
          </button>
        ))}
      </div>

      {/* Events List */}
      <div className="space-y-3">
        {getEventsForTab().length > 0 ? (
          getEventsForTab().map((event) => (
            <button
              key={event.id}
              onClick={() => onEventClick(event)}
              className="event-card w-full text-left"
            >
              <div className="event-icon">{event.emoji}</div>
              <div className="flex-1 min-w-0">
                <h3 className="font-bold text-gray-800 truncate">{event.title}</h3>
                <div className="flex items-center gap-3 mt-1 text-sm text-gray-500">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5" />
                    {event.date}, {event.time}
                  </span>
                </div>
                <div className="flex items-center gap-1 mt-1 text-sm text-gray-500">
                  <MapPin className="w-3.5 h-3.5" />
                  {event.location}
                </div>
              </div>
              {event.isGoing && (
                <span className="status-badge going">Going</span>
              )}
            </button>
          ))
        ) : (
          <div className="text-center py-12">
            <div className="w-20 h-20 rounded-full bg-purple-100 flex items-center justify-center mx-auto mb-4 text-4xl">
              🎉
            </div>
            <h3 className="text-gray-800 font-bold mb-1">No events yet</h3>
            <p className="text-gray-500 text-sm">
              {activeTab === 'upcoming' && "Events you're attending will appear here"}
              {activeTab === 'past' && "Past events will appear here"}
              {activeTab === 'hosted' && "Events you host will appear here"}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Profile;
