import { useState } from 'react';
import { Search, MapPin, Music, Home, Heart, GraduationCap } from 'lucide-react';
import { sampleEvents, type Event } from '../App';

interface DiscoverProps {
  onEventClick: (event: Event) => void;
}

const categories = [
  { id: 'all', label: 'All', icon: MapPin },
  { id: 'party', label: 'Party', icon: Music },
  { id: 'house', label: 'House Party', icon: Home },
  { id: 'wedding', label: 'Wedding', icon: Heart },
  { id: 'campus', label: 'Campus', icon: GraduationCap },
];

// Event positions on the map (percentage-based)
const eventPositions = [
  { id: '1', top: 25, left: 20 },
  { id: '2', top: 40, left: 55 },
  { id: '3', top: 65, left: 35 },
  { id: '4', top: 30, left: 75 },
  { id: '5', top: 70, left: 70 },
];

const Discover = ({ onEventClick }: DiscoverProps) => {
  const [activeCategory, setActiveCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredEvents = sampleEvents.filter(event => {
    const matchesCategory = activeCategory === 'all' || 
      event.category.toLowerCase().includes(activeCategory);
    const matchesSearch = event.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      event.location.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="p-5 pt-14">
      {/* Header */}
      <h1 className="text-3xl font-extrabold text-gray-800 mb-1">
        Find a vibe...
      </h1>
      <p className="text-gray-500 text-sm mb-6">Discover events happening near you</p>

      {/* Search Bar */}
      <div className="search-bar mb-5">
        <Search className="w-5 h-5 text-gray-400" />
        <input
          type="text"
          placeholder="Search events, locations..."
          className="flex-1 bg-transparent text-gray-700 placeholder:text-gray-400 focus:outline-none"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      {/* Category Pills */}
      <div className="flex gap-2 overflow-x-auto hide-scrollbar mb-6">
        {categories.map((cat) => {
          const Icon = cat.icon;
          return (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`category-pill ${activeCategory === cat.id ? 'active' : ''}`}
            >
              <Icon className="w-4 h-4" />
              {cat.label}
            </button>
          );
        })}
      </div>

      {/* Map Area */}
      <div className="relative h-[320px] rounded-3xl overflow-hidden mb-6 bg-gradient-to-br from-purple-100 to-blue-50">
        {/* Grid pattern */}
        <div 
          className="absolute inset-0 opacity-30"
          style={{
            backgroundImage: `
              linear-gradient(rgba(124, 58, 237, 0.1) 1px, transparent 1px),
              linear-gradient(90deg, rgba(124, 58, 237, 0.1) 1px, transparent 1px)
            `,
            backgroundSize: '40px 40px',
          }}
        />
        
        {/* Decorative areas */}
        <div className="absolute top-1/4 left-1/4 w-24 h-24 rounded-full bg-purple-200/30 blur-xl" />
        <div className="absolute bottom-1/3 right-1/4 w-32 h-32 rounded-full bg-blue-200/30 blur-xl" />
        
        {/* Street lines */}
        <svg className="absolute inset-0 w-full h-full opacity-20">
          <line x1="0" y1="35%" x2="100%" y2="35%" stroke="#7C3AED" strokeWidth="2" />
          <line x1="0" y1="65%" x2="100%" y2="65%" stroke="#7C3AED" strokeWidth="1" />
          <line x1="30%" y1="0" x2="30%" y2="100%" stroke="#7C3AED" strokeWidth="1" />
          <line x1="70%" y1="0" x2="70%" y2="100%" stroke="#7C3AED" strokeWidth="2" />
        </svg>

        {/* Event Markers */}
        {filteredEvents.map((event) => {
          const position = eventPositions.find(p => p.id === event.id);
          if (!position) return null;
          
          return (
            <button
              key={event.id}
              onClick={() => onEventClick(event)}
              className="absolute event-marker hover:scale-110 transition-transform"
              style={{ top: `${position.top}%`, left: `${position.left}%` }}
            >
              {event.emoji}
            </button>
          );
        })}

        {/* Current location */}
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
          <div className="relative">
            <div className="w-4 h-4 rounded-full bg-purple-600" />
            <div className="absolute inset-0 w-4 h-4 rounded-full bg-purple-600 animate-ping" />
            <div className="absolute -inset-2 w-8 h-8 rounded-full border-2 border-purple-400/50" />
          </div>
        </div>
      </div>

      {/* Nearby Events List */}
      <div>
        <h2 className="text-lg font-bold text-gray-800 mb-4">Nearby Jollies</h2>
        <div className="space-y-3">
          {filteredEvents.slice(0, 3).map((event) => (
            <button
              key={event.id}
              onClick={() => onEventClick(event)}
              className="event-card w-full text-left"
            >
              <div className="event-icon">{event.emoji}</div>
              <div className="flex-1 min-w-0">
                <h3 className="font-bold text-gray-800 truncate">{event.title}</h3>
                <div className="flex items-center gap-3 mt-1 text-sm text-gray-500">
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5" />
                    {event.location}
                  </span>
                </div>
                <div className="flex items-center gap-3 mt-1 text-sm text-gray-500">
                  <span>{event.date}, {event.time}</span>
                </div>
              </div>
              {event.isGoing && (
                <span className="status-badge going">Going</span>
              )}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Discover;
