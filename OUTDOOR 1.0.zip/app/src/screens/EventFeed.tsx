import { useRef, useState, useEffect } from 'react';
import EventCard, { type Event } from '../components/EventCard';
import { Search, SlidersHorizontal } from 'lucide-react';

// Sample events data
const sampleEvents: Event[] = [
  {
    id: '1',
    image: '/hero_portrait_dj.jpg',
    title: 'Afrobeat Night @ Quilox',
    host: {
      name: 'Quilox Official',
      avatar: '/mosaic_tile_03.jpg',
      verified: true,
    },
    location: 'Victoria Island, Lagos',
    date: 'Tonight',
    time: '10:00 PM',
    attendees: 234,
    category: 'Nightlife',
    isLive: true,
  },
  {
    id: '2',
    image: '/featured_block_party.jpg',
    title: 'Sunset Rooftop Party',
    host: {
      name: 'Lagos Social Club',
      avatar: '/weekend_card_03.jpg',
      verified: true,
    },
    location: 'Eko Atlantic, Lagos',
    date: 'Tomorrow',
    time: '6:00 PM',
    attendees: 156,
    category: 'Party',
  },
  {
    id: '3',
    image: '/weekend_card_02.jpg',
    title: 'House Party - Lekki Phase 1',
    host: {
      name: 'Tunde',
      avatar: '/mosaic_tile_03.jpg',
    },
    location: 'Lekki Phase 1, Lagos',
    date: 'Saturday',
    time: '8:00 PM',
    attendees: 45,
    category: 'House Party',
  },
  {
    id: '4',
    image: '/weekend_card_01.jpg',
    title: 'Wedding After-Party',
    host: {
      name: 'Chioma & David',
      avatar: '/category_tile_05.jpg',
    },
    location: 'Eko Hotel, Victoria Island',
    date: 'Sunday',
    time: '6:00 PM',
    attendees: 120,
    category: 'Wedding',
  },
  {
    id: '5',
    image: '/trending_01.jpg',
    title: 'Campus Hangout - UNILAG',
    host: {
      name: 'Campus Vibes',
      avatar: '/category_tile_04.jpg',
      verified: true,
    },
    location: 'UNILAG Campus, Akoka',
    date: 'Friday',
    time: '4:00 PM',
    attendees: 89,
    category: 'Campus',
  },
  {
    id: '6',
    image: '/nightlife_right_bottom_dance.jpg',
    title: 'DJ Spinall Live',
    host: {
      name: 'Spinall Official',
      avatar: '/mosaic_tile_01.jpg',
      verified: true,
    },
    location: 'Hard Rock Cafe, Lagos',
    date: 'Tonight',
    time: '11:00 PM',
    attendees: 312,
    category: 'Concert',
    isLive: true,
  },
];

const EventFeed = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [activeIndex, setActiveIndex] = useState(0);
  const [showSearch, setShowSearch] = useState(false);

  // Handle scroll to update active index
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const handleScroll = () => {
      const scrollTop = container.scrollTop;
      const cardHeight = container.clientHeight;
      const newIndex = Math.round(scrollTop / cardHeight);
      setActiveIndex(Math.min(newIndex, sampleEvents.length - 1));
    };

    container.addEventListener('scroll', handleScroll, { passive: true });
    return () => container.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="relative h-full">
      {/* Search & Filter Bar */}
      <div className="absolute top-0 left-0 right-0 z-20 p-4 pt-12">
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setShowSearch(!showSearch)}
            className="flex-1 flex items-center gap-2 px-4 py-2.5 rounded-full bg-black/50 backdrop-blur-md"
          >
            <Search className="w-4 h-4 text-white/60" />
            <span className="text-white/60 text-sm">Search events...</span>
          </button>
          <button className="w-10 h-10 rounded-full bg-black/50 backdrop-blur-md flex items-center justify-center">
            <SlidersHorizontal className="w-5 h-5 text-white" />
          </button>
        </div>

        {/* Category Pills */}
        <div className="flex gap-2 mt-3 overflow-x-auto hide-scrollbar">
          {['All', 'Tonight', 'Parties', 'Nightlife', 'Weddings', 'Campus', 'Food'].map((cat, i) => (
            <button
              key={cat}
              className={`px-4 py-1.5 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
                i === 0 
                  ? 'bg-[#FFFC00] text-black' 
                  : 'bg-black/50 text-white backdrop-blur-md'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Event Cards Container */}
      <div
        ref={containerRef}
        className="snap-container hide-scrollbar"
      >
        {sampleEvents.map((event) => (
          <EventCard
            key={event.id}
            event={event}
          />
        ))}
      </div>

      {/* Scroll Indicator */}
      <div className="absolute right-4 bottom-24 flex flex-col gap-1">
        {sampleEvents.map((_, index) => (
          <div
            key={index}
            className={`w-1 rounded-full transition-all duration-300 ${
              index === activeIndex 
                ? 'h-6 bg-[#FFFC00]' 
                : 'h-2 bg-white/30'
            }`}
          />
        ))}
      </div>

      {/* Search Modal */}
      {showSearch && (
        <div className="absolute inset-0 z-30 bg-black/95 backdrop-blur-xl p-4 pt-12">
          <div className="flex items-center gap-3 mb-6">
            <input
              type="text"
              placeholder="Search events, locations, hosts..."
              className="flex-1 px-4 py-3 rounded-full bg-white/10 text-white placeholder:text-white/40 focus:outline-none focus:ring-2 focus:ring-[#FFFC00]"
              autoFocus
            />
            <button 
              onClick={() => setShowSearch(false)}
              className="text-white font-medium"
            >
              Cancel
            </button>
          </div>
          
          <div className="space-y-4">
            <h3 className="text-white/60 text-sm font-medium uppercase tracking-wide">
              Trending Searches
            </h3>
            {['Afrobeat', 'Lekki parties', 'House music', 'Wedding', 'Campus'].map((term) => (
              <button
                key={term}
                className="block w-full text-left text-white py-2 hover:text-[#FFFC00] transition-colors"
              >
                {term}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default EventFeed;
