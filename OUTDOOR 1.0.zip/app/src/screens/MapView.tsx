import { useState } from 'react';
import { Search, Navigation, MapPin } from 'lucide-react';

// Sample map events
const mapEvents = [
  { id: '1', lat: 30, lng: 40, title: 'Afrobeat Night', attendees: 234 },
  { id: '2', lat: 50, lng: 60, title: 'Rooftop Party', attendees: 156 },
  { id: '3', lat: 70, lng: 30, title: 'House Party', attendees: 45 },
  { id: '4', lat: 40, lng: 70, title: 'Wedding Party', attendees: 120 },
];

const MapView = () => {
  const [selectedEvent, setSelectedEvent] = useState<string | null>(null);

  return (
    <div className="relative h-full bg-[#1a1a2e]">
      {/* Search Bar */}
      <div className="absolute top-0 left-0 right-0 z-20 p-4 pt-12">
        <div className="flex items-center gap-3">
          <div className="flex-1 flex items-center gap-2 px-4 py-2.5 rounded-full bg-black/50 backdrop-blur-md">
            <Search className="w-4 h-4 text-white/60" />
            <span className="text-white/60 text-sm">Search location...</span>
          </div>
          <button className="w-10 h-10 rounded-full bg-[#FFFC00] flex items-center justify-center">
            <Navigation className="w-5 h-5 text-black" />
          </button>
        </div>
      </div>

      {/* Stylized Map Background */}
      <div className="absolute inset-0">
        {/* Grid pattern */}
        <div 
          className="absolute inset-0 opacity-20"
          style={{
            backgroundImage: `
              linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
              linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)
            `,
            backgroundSize: '50px 50px',
          }}
        />
        
        {/* Decorative circles representing areas */}
        <div className="absolute top-1/4 left-1/4 w-32 h-32 rounded-full bg-[#FFFC00]/10 blur-xl" />
        <div className="absolute top-1/2 right-1/3 w-48 h-48 rounded-full bg-[#00D9FF]/10 blur-xl" />
        <div className="absolute bottom-1/3 left-1/2 w-40 h-40 rounded-full bg-[#FFFC00]/5 blur-xl" />

        {/* Street lines */}
        <svg className="absolute inset-0 w-full h-full opacity-30">
          <line x1="0" y1="30%" x2="100%" y2="30%" stroke="white" strokeWidth="2" />
          <line x1="0" y1="60%" x2="100%" y2="60%" stroke="white" strokeWidth="1" />
          <line x1="25%" y1="0" x2="25%" y2="100%" stroke="white" strokeWidth="1" />
          <line x1="50%" y1="0" x2="50%" y2="100%" stroke="white" strokeWidth="2" />
          <line x1="75%" y1="0" x2="75%" y2="100%" stroke="white" strokeWidth="1" />
        </svg>
      </div>

      {/* Event Pins */}
      {mapEvents.map((event) => (
        <button
          key={event.id}
          onClick={() => setSelectedEvent(event.id)}
          className="absolute transform -translate-x-1/2 -translate-y-1/2"
          style={{ left: `${event.lng}%`, top: `${event.lat}%` }}
        >
          <div className={`relative transition-transform ${selectedEvent === event.id ? 'scale-125' : ''}`}>
            <div className="w-12 h-12 rounded-full bg-[#FFFC00] flex items-center justify-center shadow-lg">
              <MapPin className="w-6 h-6 text-black" />
            </div>
            <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-3 h-3 bg-[#FFFC00] rotate-45" />
            
            {/* Attendee count badge */}
            <div className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-black text-[#FFFC00] text-[10px] font-bold flex items-center justify-center border border-[#FFFC00]">
              {event.attendees > 99 ? '99+' : event.attendees}
            </div>
          </div>
        </button>
      ))}

      {/* Current location indicator */}
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
        <div className="relative">
          <div className="w-4 h-4 rounded-full bg-[#00D9FF]" />
          <div className="absolute inset-0 w-4 h-4 rounded-full bg-[#00D9FF] animate-ping" />
          <div className="absolute -inset-2 w-8 h-8 rounded-full border-2 border-[#00D9FF]/50" />
        </div>
      </div>

      {/* Bottom Event Cards */}
      <div className="absolute bottom-20 left-0 right-0 px-4">
        <div className="flex gap-3 overflow-x-auto hide-scrollbar pb-2">
          {mapEvents.map((event) => (
            <button
              key={event.id}
              onClick={() => setSelectedEvent(event.id)}
              className={`flex-shrink-0 w-48 p-3 rounded-2xl backdrop-blur-md transition-all ${
                selectedEvent === event.id 
                  ? 'bg-[#FFFC00] text-black' 
                  : 'bg-black/60 text-white'
              }`}
            >
              <h4 className="font-semibold text-sm">{event.title}</h4>
              <p className={`text-xs mt-1 ${selectedEvent === event.id ? 'text-black/70' : 'text-white/60'}`}>
                {event.attendees} people going
              </p>
            </button>
          ))}
        </div>
      </div>

      {/* Zoom Controls */}
      <div className="absolute right-4 top-1/2 -translate-y-1/2 flex flex-col gap-2">
        <button className="w-10 h-10 rounded-full bg-black/60 backdrop-blur-md flex items-center justify-center text-white text-xl font-bold">
          +
        </button>
        <button className="w-10 h-10 rounded-full bg-black/60 backdrop-blur-md flex items-center justify-center text-white text-xl font-bold">
          −
        </button>
      </div>
    </div>
  );
};

export default MapView;
