import { Map, Plus, User } from 'lucide-react';
import type { Tab } from '../App';

interface BottomNavProps {
  activeTab: Tab;
  onTabChange: (tab: Tab) => void;
}

const BottomNav = ({ activeTab, onTabChange }: BottomNavProps) => {
  return (
    <nav className="bottom-nav z-50 max-w-md mx-auto">
      {/* Discover */}
      <button
        onClick={() => onTabChange('discover')}
        className={`nav-item ${activeTab === 'discover' ? 'active' : ''}`}
      >
        <Map className="w-6 h-6" strokeWidth={activeTab === 'discover' ? 2.5 : 2} />
        <span className="text-[11px] font-semibold uppercase tracking-wide">Discover</span>
      </button>

      {/* Create (Center) */}
      <button
        onClick={() => onTabChange('create')}
        className="create-btn"
      >
        <Plus className="w-8 h-8 text-white" strokeWidth={3} />
      </button>

      {/* Profile */}
      <button
        onClick={() => onTabChange('profile')}
        className={`nav-item ${activeTab === 'profile' ? 'active' : ''}`}
      >
        <User className="w-6 h-6" strokeWidth={activeTab === 'profile' ? 2.5 : 2} />
        <span className="text-[11px] font-semibold uppercase tracking-wide">Profile</span>
      </button>
    </nav>
  );
};

export default BottomNav;
