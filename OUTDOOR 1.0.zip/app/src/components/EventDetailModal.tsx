import { useState } from 'react';
import { X, MapPin, Calendar, Phone, MessageCircle, Share2, Check } from 'lucide-react';
import type { Event } from '../App';

interface EventDetailModalProps {
  event: Event;
  onClose: () => void;
}

const EventDetailModal = ({ event, onClose }: EventDetailModalProps) => {
  const [isGoing, setIsGoing] = useState(event.isGoing || false);
  const [showChatPopup, setShowChatPopup] = useState(false);
  const [showPhone, setShowPhone] = useState(false);

  const handleGoing = () => {
    setIsGoing(!isGoing);
  };

  const handleMessage = () => {
    setShowChatPopup(true);
    // Auto-hide after 5 seconds
    setTimeout(() => setShowChatPopup(false), 5000);
  };

  const handleCall = () => {
    setShowPhone(true);
  };

  const openWhatsApp = () => {
    const message = encodeURIComponent(`Hi ${event.host.name}! I'm interested in your event "${event.title}" on ${event.date}. Is it still on?`);
    window.open(`https://wa.me/${event.host.phone.replace(/\D/g, '')}?text=${message}`, '_blank');
  };

  return (
    <div className="modal-overlay">
      <div className="modal-content">
        {/* Header with Emoji */}
        <div className="relative h-32 bg-gradient-to-br from-purple-100 to-blue-100 flex items-center justify-center">
          <button 
            onClick={onClose}
            className="absolute top-4 right-4 w-10 h-10 rounded-full bg-white/80 flex items-center justify-center"
          >
            <X className="w-5 h-5 text-gray-600" />
          </button>
          <span className="text-7xl">{event.emoji}</span>
        </div>

        {/* Content */}
        <div className="p-5">
          {/* Title & Category */}
          <h2 className="text-2xl font-extrabold text-gray-800">{event.title}</h2>
          <span className="inline-block mt-2 px-3 py-1 rounded-full bg-purple-100 text-purple-700 text-sm font-semibold">
            {event.category}
          </span>

          {/* Host Info */}
          <div className="flex items-center gap-3 mt-5 p-4 rounded-2xl bg-gray-50">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-200 to-blue-200 flex items-center justify-center text-2xl">
              😊
            </div>
            <div className="flex-1">
              <p className="font-bold text-gray-800">{event.host.name}</p>
              <p className="text-sm text-gray-500">Host</p>
            </div>
          </div>

          {/* Details */}
          <div className="space-y-4 mt-5">
            <div className="flex items-center gap-3 text-gray-700">
              <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center">
                <Calendar className="w-5 h-5 text-purple-600" />
              </div>
              <div>
                <p className="font-semibold">{event.date}</p>
                <p className="text-sm text-gray-500">{event.time}</p>
              </div>
            </div>

            <div className="flex items-center gap-3 text-gray-700">
              <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center">
                <MapPin className="w-5 h-5 text-purple-600" />
              </div>
              <div>
                <p className="font-semibold">{event.location}</p>
                <p className="text-sm text-gray-500">Tap to get directions</p>
              </div>
            </div>

            {event.entryFee && (
              <div className="flex items-center gap-3 text-gray-700">
                <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
                  <span className="text-green-600 font-bold text-sm">₦</span>
                </div>
                <div>
                  <p className="font-semibold">{event.entryFee}</p>
                  <p className="text-sm text-gray-500">Entry fee</p>
                </div>
              </div>
            )}
          </div>

          {/* Description */}
          {event.description && (
            <div className="mt-5 p-4 rounded-2xl bg-gray-50">
              <p className="text-gray-700">{event.description}</p>
            </div>
          )}

          {/* Contact Section */}
          <div className="mt-5">
            <p className="text-sm font-semibold text-gray-500 mb-3 uppercase tracking-wide">Contact Host</p>
            <div className="flex gap-3">
              <button
                onClick={handleMessage}
                className="flex-1 flex items-center justify-center gap-2 py-3 rounded-2xl bg-purple-100 text-purple-700 font-semibold"
              >
                <MessageCircle className="w-5 h-5" />
                Message
              </button>
              <button
                onClick={handleCall}
                className="flex-1 flex items-center justify-center gap-2 py-3 rounded-2xl bg-green-100 text-green-700 font-semibold"
              >
                <Phone className="w-5 h-5" />
                Call
              </button>
            </div>
          </div>

          {/* Phone Number Display */}
          {showPhone && (
            <div className="mt-3 p-4 rounded-2xl bg-gray-100 text-center">
              <p className="text-lg font-bold text-gray-800">{event.host.phone}</p>
              <a 
                href={`tel:${event.host.phone}`}
                className="inline-block mt-2 px-4 py-2 rounded-full bg-green-500 text-white font-semibold text-sm"
              >
                Call Now
              </a>
            </div>
          )}
        </div>

        {/* Bottom Actions */}
        <div className="p-5 border-t border-gray-100 flex gap-3">
          <button
            onClick={handleGoing}
            className={`flex-1 py-4 rounded-full font-bold text-lg transition-all flex items-center justify-center gap-2 ${
              isGoing
                ? 'bg-green-500 text-white'
                : 'btn-primary'
            }`}
          >
            {isGoing && <Check className="w-5 h-5" />}
            {isGoing ? 'Going' : "I'm Going"}
          </button>
          <button className="w-14 h-14 rounded-full bg-gray-100 flex items-center justify-center">
            <Share2 className="w-5 h-5 text-gray-600" />
          </button>
        </div>
      </div>

      {/* Chat Popup */}
      {showChatPopup && (
        <div className="chat-popup">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-200 to-blue-200 flex items-center justify-center text-lg flex-shrink-0">
              😊
            </div>
            <div>
              <p className="font-bold text-gray-800 text-sm">{event.host.name}</p>
              <p className="text-gray-600 text-sm mt-1">
                Hey! Want to chat about the event?
              </p>
            </div>
          </div>
          <div className="flex gap-2 mt-3">
            <button
              onClick={openWhatsApp}
              className="flex-1 py-2 rounded-full bg-green-500 text-white font-semibold text-sm"
            >
              WhatsApp
            </button>
            <button
              onClick={() => setShowChatPopup(false)}
              className="flex-1 py-2 rounded-full bg-gray-100 text-gray-600 font-semibold text-sm"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default EventDetailModal;
