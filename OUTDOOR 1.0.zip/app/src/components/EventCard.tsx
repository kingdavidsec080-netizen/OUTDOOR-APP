import { useState } from 'react';
import { Heart, MessageCircle, Share2, MapPin, Clock, Users, Navigation } from 'lucide-react';

export interface Event {
  id: string;
  image: string;
  title: string;
  host: {
    name: string;
    avatar: string;
    verified?: boolean;
  };
  location: string;
  date: string;
  time: string;
  attendees: number;
  category: string;
  isLive?: boolean;
}

interface EventCardProps {
  event: Event;
}

const EventCard = ({ event }: EventCardProps) => {
  const [isInterested, setIsInterested] = useState(false);
  const [showHeartAnim, setShowHeartAnim] = useState(false);

  const handleInterested = () => {
    setIsInterested(!isInterested);
    if (!isInterested) {
      setShowHeartAnim(true);
      setTimeout(() => setShowHeartAnim(false), 300);
    }
  };

  return (
    <div className="event-card relative">
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src={event.image}
          alt={event.title}
          className="w-full h-full object-cover"
        />
      </div>

      {/* Top Gradient */}
      <div className="absolute inset-x-0 top-0 h-32 top-gradient" />

      {/* Bottom Gradient */}
      <div className="absolute inset-x-0 bottom-0 h-[60%] gradient-overlay" />

      {/* Top Bar - Host Info */}
      <div className="absolute top-0 left-0 right-0 p-4 pt-12 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="host-avatar">
            <img
              src={event.host.avatar}
              alt={event.host.name}
              className="w-full h-full object-cover"
            />
          </div>
          <div>
            <p className="text-white font-semibold text-sm text-shadow">
              {event.host.name}
            </p>
            {event.host.verified && (
              <span className="text-[10px] text-white/70">Verified Host</span>
            )}
          </div>
        </div>

        {event.isLive && (
          <div className="flex items-center gap-1.5 px-2 py-1 rounded-full bg-red-500/80">
            <div className="w-2 h-2 rounded-full bg-white pulse" />
            <span className="text-white text-xs font-semibold">LIVE</span>
          </div>
        )}
      </div>

      {/* Right Side Actions */}
      <div className="absolute right-4 top-1/2 -translate-y-1/2 flex flex-col gap-4">
        <button
          onClick={handleInterested}
          className={`action-btn ${showHeartAnim ? 'heart-animate' : ''}`}
        >
          <Heart
            className={`w-6 h-6 transition-colors ${
              isInterested ? 'fill-[#FFFC00] text-[#FFFC00]' : 'text-white'
            }`}
          />
        </button>
        <span className="text-white text-xs text-center -mt-2">
          {event.attendees + (isInterested ? 1 : 0)}
        </span>

        <button className="action-btn">
          <MessageCircle className="w-6 h-6 text-white" />
        </button>

        <button className="action-btn">
          <Share2 className="w-6 h-6 text-white" />
        </button>

        <button className="action-btn">
          <Navigation className="w-6 h-6 text-white" />
        </button>
      </div>

      {/* Bottom Info */}
      <div className="absolute bottom-24 left-4 right-20">
        {/* Category Tag */}
        <span className="category-chip text-white mb-3 inline-block">
          {event.category}
        </span>

        {/* Title */}
        <h2 className="text-white text-2xl font-bold text-shadow mb-3 leading-tight">
          {event.title}
        </h2>

        {/* Details */}
        <div className="space-y-1.5">
          <div className="flex items-center gap-2 text-white/80">
            <MapPin className="w-4 h-4" />
            <span className="text-sm">{event.location}</span>
          </div>
          <div className="flex items-center gap-2 text-white/80">
            <Clock className="w-4 h-4" />
            <span className="text-sm">{event.date} • {event.time}</span>
          </div>
          <div className="flex items-center gap-2 text-white/80">
            <Users className="w-4 h-4" />
            <span className="text-sm">{event.attendees} people going</span>
          </div>
        </div>
      </div>

      {/* Bottom Action Bar */}
      <div className="absolute bottom-4 left-4 right-4 flex gap-3">
        <button className="btn-primary flex-1">
          I&apos;m Going
        </button>
        <button className="btn-secondary flex-1">
          Maybe
        </button>
      </div>
    </div>
  );
};

export default EventCard;
